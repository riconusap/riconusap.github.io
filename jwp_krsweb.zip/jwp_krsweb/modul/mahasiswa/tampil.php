<?php
//memasukkan file config.php
include('../../assets/relasi/koneksi.php');
?>

<div class="container" style="margin-top:20px">
	<center>
		<font size="6">DATA MATA KULIAH</font>
	</center>
	<hr>
	<button class="btn button button__first my-4"><a href="index.php?page=tambah_mahasiswa">Tambah Data</a></button>
	<div class="table-responsive">
		<table class="table table-striped jambo_table bulk_action">
			<thead>
				<tr>
					<th>NO.</th>
					<th>NPM</th>
					<th>Nama Mahasiswa</th>
					<th>Kelas</th>
					<th>Aksi</th>
				</tr>
			</thead>
			<tbody>
				<?php
				//query ke database SELECT tabel produk
				$sql = mysqli_query($konek, "SELECT * FROM mahasiswa") or die(mysqli_error($konek));
				//jika query diatas menghasilkan nilai > 0 maka menjalankan script di bawah if...
				if (mysqli_num_rows($sql) > 0) {
					//membuat variabel $no untuk menyimpan nomor urut
					$no = 1;
					//melakukan perulangan while dengan dari dari query $sql
					while ($data = mysqli_fetch_assoc($sql)) {
						//menampilkan data perulangan
						echo '
						<tr>
							<td>' . $no . '</td>
							<td>' . $data['npm'] . '</td>
							<td>' . $data['nama_mahasiswa'] . '</td>
							<td>' . $data['kelas'] . '</td>

							<td>
								<button class="btn button button__first"><a href="index.php?page=data_krs&id=' . $data['npm'] . '" >Cek KRS</a></button> 
								<button class="btn button button__secondary"><a href="index.php?page=edit_mahasiswa&id=' . $data['npm'] . '" >Edit</a></button>
								<button class="btn button button__danger"><a href="modul/mahasiswa/delete.php?id=' . $data['npm'] . '" onclick="return confirm(\'Yakin ingin menghapus data ini?\')">Delete</a></button>
							</td>
						</tr>
						';
						$no++;
					}
					//jika query menghasilkan nilai 0
				} else {
					echo '
					<tr>
						<td colspan="8">Tidak ada data.</td>
					</tr>
					';
				}
				?>
			<tbody>
		</table>
	</div>
</div>