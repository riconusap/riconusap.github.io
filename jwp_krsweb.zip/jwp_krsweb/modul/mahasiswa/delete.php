<?php
//include file config.php
include('../../assets/relasi/koneksi.php');
//jika benar mendapatkan GET id dari URL
if (isset($_GET['id'])) {
	//membuat variabel $id yang menyimpan nilai dari $_GET['id']
	$id = $_GET['id'];

	//melakukan query ke database, dengan cara SELECT data yang memiliki id yang sama dengan variabel $id
	$cek = mysqli_query($konek, "SELECT * FROM mahasiswa WHERE npm='$id'") or die(mysqli_error($konek));
	$cek_login = mysqli_query($konek, "SELECT * FROM user WHERE id_user='$id'") or die(mysqli_error($konek));
	$data = mysqli_fetch_assoc($cek);
	$data_login = mysqli_fetch_assoc($cek_login);
	//jika query menghasilkan nilai > 0 maka eksekusi script di bawah
	if (mysqli_num_rows($cek) > 0 && mysqli_num_rows($cek_login) > 0) {
		//query ke database DELETE untuk menghapus data dengan kondisi id=$id
		$del = mysqli_query($konek, "DELETE FROM mahasiswa WHERE npm='$id'") or die(mysqli_error($konek));
		$del_login = mysqli_query($konek, "DELETE FROM user WHERE id_user='$id'") or die(mysqli_error($konek));
		if ($del && $del_login) {
			echo '<script>alert("Berhasil menghapus data."); document.location="../../index.php?page=data_mahasiswa";</script>';
		} else {
			echo '<script>alert("Gagal menghapus data."); document.location="../../index.php?page=data_mahasiswa";</script>';
		}
	} else {
		echo '<script>alert("ID tidak ditemukan di database."); document.location="../../index.php?page=data_mahasiswa";</script>';
	}
} else {
	echo '<script>alert("ID tidak ditemukan di database."); document.location="../../index.php?page=data_mahasiswa";</script>';
}
