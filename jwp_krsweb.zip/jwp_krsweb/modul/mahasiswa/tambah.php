<?php

include('../../assets/relasi/koneksi.php');

?>

<?php
if (isset($_POST['submit'])) {

	$npm 	= $_POST['npm'];
	$name	= $_POST['name'];
	$kelas	= $_POST['kelas'];
	$password = md5('mahasiswa');
	$level	= "mahasiswa";

				$cek = mysqli_query($konek, "SELECT * FROM mahasiswa WHERE npm='$id'") or die(mysqli_error($konek));
				if (mysqli_num_rows($cek) == 0) {
					mysqli_query($konek, "INSERT INTO mahasiswa VALUES('$npm' ,'$name','$kelas')") or die(mysqli_error($konek));
					mysqli_query($konek, "INSERT INTO user VALUES(id_login=null, '$npm' ,'$password', '$level')") or die(mysqli_error($konek));
					mysqli_query($konek, "INSERT INTO krs VALUES(id_krs=null, '$npm')") or die(mysqli_error($konek));
					echo '<script>
							alert("Berhasil menambahkan data.");
							document.location = "index.php?page=data_mahasiswa";
							</script>';
				} else {
					echo '<script>
							alert("Tidak Berhasil Menambahkan Data ke Database.");
							document.location = "index.php?page=data_mahasiswa";
						  </script>';
				}
			}
?>



<section class="contact-clean" style="background: #f1f7fc;">
<form class="d-flex d-xxl-flex flex-column" action="index.php?page=tambah_mahasiswa" method="post" enctype="multipart/form-data">
        <h2 class="text-center">Masukan Data Mahasiswa</h2>
        <div class="mb-3">
			<input type="text" class="form-control" name="npm" placeholder="NPM" style="border-color: var(--bs-purple);" />
		</div>
        <div class="mb-3">
			<input type="text" class="form-control" name="name" placeholder="Nama Mahasiswa" style="border-color: var(--bs-purple);" />
		</div>
        <div class="mb-3">
			<input type="text" class="form-control" name="kelas" placeholder="Kelas" style="border-color: var(--bs-purple);" />
		</div>
        <div class="mb-3"></div>
        <div class="d-flex justify-content-evenly align-items-center align-items-xxl-center mb-3">
			<button class="btn button button__first" type="submit" name="submit">Submit</button>
		</div>
    </form>
</section>
</div>