<?php

include('../../assets/relasi/koneksi.php');


?>

<?php
if (isset($_POST['submit'])) {
	$matkul = $_POST['matkul'];
	foreach ($matkul as $key => $value) {
					$ambil_id_krs = mysqli_fetch_assoc(mysqli_query($konek,"SELECT * from krs where npm='$akun'"));
					$id_krs = $ambil_id_krs['id_krs'];
					mysqli_query($konek, "INSERT INTO list_matkul_krs VALUES(null ,'$id_krs','$matkul[$key]')") or die(mysqli_error($konek));
					echo '<script>
							alert("Berhasil menambahkan data.");
							document.location = "index.php?page=data_krs";
							</script>';
			}
		}
?>



<!-- <section class="contact-clean" style="background: #f1f7fc;"> -->
<form class="d-flex d-xxl-flex flex-column" action="index.php?page=tambah_krs&id=<?php echo $id ?>" method="post" enctype="multipart/form-data">
<div class="container-fluid">
	
    <h3 class="text-center text-dark mb-4">Isi KRS&nbsp;</h3>
        <div class="card-header py-3"></div>
        <div class="card-body">
            <div class="row">
				
                <table id="table_field" class="col-auto d-xl-flex justify-content-xl-center" style="width: 100%;margin-bottom: 10px;">
                    <tr>
                        <th>
                            Pilih Matkul
                        </th>
                        <th>
                            Aksi
                        </th>
                    </tr>
                    <tr>
                        <td>
							<select name="matkul[]" class="form-control">
								<option selected>Pilih Mata Kuliah</option>
								<?php
									$cek = mysqli_query($konek, "SELECT * FROM mata_kuliah");
									while ($data=mysqli_fetch_assoc($cek)) {
									echo '<option value="'. $data['id_matkul'] .'">'. $data['nama_matkul'] .' - '. $data['sks'] .' SKS </option>';
									} 
								?>
							</select>
                        </td>
                        <td>
                        <input  id="tombol_tambah" type="button" name="add" class="btn button button__first m-3" value="ADD">
                        </td>
                    </tr>
                </table>
				
				<div class="item form-group d-flex justify-content-center w-100 mt-4">
					<div class="col-md-6 col-sm-6 offset-md-3 d-flex f-left">
						<input  id="tombol" type="submit" name="submit" class="btn button button__first m-3" value="Simpan">
						<a href="index.php?page=data_krs" class="btn button button__secondary m-3">Kembali</a>
					</div>
				</div>

            </div>
        </div>
    </div>
</div>
</form>
<!-- </section> -->
<script type="text/javascript">
    $(document).ready(function(){
        var html = '<tr><td><select name="matkul[]" class="form-control" aria-label="Default select example"><option selected>Pilih Mata Kuliah</option><?php $cek = mysqli_query($konek, "SELECT * FROM mata_kuliah");while ($data=mysqli_fetch_assoc($cek)) {echo '<option value="'. $data['id_matkul'] .'">'. $data['nama_matkul'] .' - '. $data['sks'] .' SKS </option>';} ?></select></td><td><input  id="tombol_hapus" type="button" name="hapus" class="btn button button__danger m-3" value="Hapus"></td></tr>';
        var max = 12;
        var x = 1;

        $("#tombol_tambah").click(function () {
            if (x<max) {
                $("#table_field").append(html);
                x++;
            }
        });

        $("#table_field").on('click','#tombol_hapus',function() {
           $(this).closest('tr').remove();
           x--; 
        });
    }
	);
</script>
