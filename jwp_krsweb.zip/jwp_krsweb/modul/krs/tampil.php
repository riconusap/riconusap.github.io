<?php
if (isset($_SESSION['admin'])) {
	if (isset($_GET['id'])) {
		//membuat variabel $id untuk menyimpan id dari GET id di URL
		$id = $_GET['id'];
		$query = "SELECT krs.npm, list_matkul_krs.id_matkul, mata_kuliah.nama_matkul, mata_kuliah.sks FROM list_matkul_krs INNER JOIN mata_kuliah ON list_matkul_krs.id_matkul = mata_kuliah.id_matkul JOIN krs ON list_matkul_krs.id_krs = krs.id_krs WHERE  npm = '$id'";
		$button_tambah = '';
	}
} else {
		
		$cek_krs = mysqli_fetch_assoc(mysqli_query($konek, "select * from krs where npm='$akun'"));
		$id_krs = $cek_krs['id_krs'];
		$cek_list_krs = mysqli_fetch_row(mysqli_query($konek, "select * from list_matkul_krs where id_krs='$id_krs'"));
		$query = "SELECT list_matkul_krs.id_matkul, mata_kuliah.nama_matkul, mata_kuliah.sks FROM list_matkul_krs INNER JOIN mata_kuliah ON list_matkul_krs.id_matkul = mata_kuliah.id_matkul WHERE id_krs = '$id_krs'";
		if ($cek_list_krs > 0) {
			$button_tambah = '<button class="btn button button__danger my-4"><a href="modul/krs/delete.php?id=' . $id_krs. '" onclick="return confirm(\'Yakin ingin menghapus data ini?\')">Hapus KRS</a></button>';
		} else {
			$button_tambah = '<button class="btn button button__first my-4"><a href="index.php?page=tambah_krs&id='. $akun .'">Tambah Data KRS</a></button>';
		}
}

?>
<div class="container" style="margin-top:20px">
	<center>
		<font size="6">DATA KRS</font>
	</center>
	<hr>
	<?php
	
	?>
	
	<div class="table-responsive">
		<?php echo $button_tambah ?>
		<table class="table table-striped jambo_table bulk_action">
			<thead>
				<tr>
					<th>NO.</th>
					<th>Kode Mata Kuliah</th>
					<th>Nama Mata Kuliah</th>
					<th>SKS</th>
				</tr>
			</thead>
			<tbody>
				<?php
				//query ke database SELECT tabel produk
				$sql = mysqli_query($konek, "$query");
				//jika query diatas menghasilkan nilai > 0 maka menjalankan script di bawah if...
				if (mysqli_num_rows($sql) > 0) {
					//membuat variabel $no untuk menyimpan nomor urut
					$no = 1;
					//melakukan perulangan while dengan dari dari query $sql
					while ($data = mysqli_fetch_assoc($sql)) {
						//menampilkan data perulangan
						echo '
						<tr>
							<td>' . $no . '</td>
							<td>' . $data['id_matkul'] . '</td>
							<td>' . $data['nama_matkul'] . '</td>
							<td>' . $data['sks'] . '</td>

						</tr>
						';
						$no++;
					}
					//jika query menghasilkan nilai 0
				} else {
					echo '
					<tr>
						<td colspan="5">Tidak ada data.</td>
					</tr>
					';
				}
				?>
			<tbody>
		</table>
	</div>
</div>