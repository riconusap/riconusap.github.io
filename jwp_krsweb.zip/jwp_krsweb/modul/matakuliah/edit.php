<?php

include('../../assets/relasi/koneksi.php');

?>


<div class="container" style="margin-top:20px">

	<hr>

	<?php
	//jika sudah mendapatkan parameter GET id dari URL
	if (isset($_GET['id'])) {
		//membuat variabel $id untuk menyimpan id dari GET id di URL
		$id = $_GET['id'];

		//query ke database SELECT tabel produk berdasarkan id = $id
		$select = mysqli_query($konek, "SELECT * FROM mata_kuliah WHERE id_matkul='$id'") or die(mysqli_error($konek));

		//jika hasil query = 0 maka muncul pesan error
		if (mysqli_num_rows($select) == 0) {
			echo '<div class="alert alert-warning">ID tidak ada dalam database.</div>';
			exit();
			//jika hasil query > 0
		} else {
			//membuat variabel $data dan menyimpan data row dari query
			$data = mysqli_fetch_assoc($select);
		}
	}
	?>

	<?php
	if (isset($_POST['submit'])) {
		$name	= $_POST['name'];
		$sks	= $_POST['sks'];

		mysqli_query($konek, "UPDATE mata_kuliah SET nama_matkul='$name', sks='$sks' WHERE id_matkul='$id'") or die(mysqli_error($konek));
		echo '<script>
			alert("Berhasil menambahkan data.");
			document.location = "index.php?page=data_matakuliah";
			</script>';
	}
	?>

	<section class="contact-clean" style="background: #f1f7fc;">
	<form action="index.php?page=edit_matakuliah&id=<?php echo $id; ?>" method="post" enctype="multipart/form-data">
        <h2 class="text-center">Edit Data Mata Kuliah</h2>
        <div class="mb-3">
			<input type="text" class="form-control" disabled name="kd_matakuliah" value="<?php echo $data['id_matkul']; ?>" style="border-color: var(--bs-purple);" />
		</div>
        <div class="mb-3">
			<input type="text" class="form-control" name="name" value="<?php echo $data['nama_matkul']; ?>" style="border-color: var(--bs-purple);" />
		</div>
        <div class="mb-3">
			<input type="number" class="form-control"  style="border-color: var(--bs-purple);" max="6" min="1" name="sks" value="<?php echo $data['sks']; ?>" />
		</div>
        <div class="mb-3"></div>
        <div class="d-flex justify-content-evenly align-items-center align-items-xxl-center mb-3">
			<button class="btn button button__first" type="submit" name="submit">Submit</button>
		</div>
    </form>
</section>

</div>