<?php

include('../../assets/relasi/koneksi.php');

?>

<?php
if (isset($_POST['submit'])) {

	$id 	= $_POST['kd_matakuliah'];
	$name	= $_POST['name'];
	$sks	= $_POST['sks'];


				$cek = mysqli_query($konek, "SELECT * FROM mata_kuliah WHERE id_matkul='$id'") or die(mysqli_error($konek));
				if (mysqli_num_rows($cek) == 0) {
					mysqli_query($konek, "INSERT INTO mata_kuliah VALUES('$id' ,'$name','$sks')") or die(mysqli_error($konek));
					echo '<script>
							alert("Berhasil menambahkan data.");
							document.location = "index.php?page=data_matakuliah";
							</script>';
				} else {
					echo '<script>
							alert("Tidak Berhasil Menambahkan Data ke Database.");
							document.location = "index.php?page=data_matakuliah";
						  </script>';
				}
			}
?>



<section class="contact-clean" style="background: #f1f7fc;">
<form class="d-flex d-xxl-flex flex-column" action="index.php?page=tambah_matakuliah" method="post" enctype="multipart/form-data">
        <h2 class="text-center">Masukan Data Mata Kuliah</h2>
        <div class="mb-3">
			<input type="text" class="form-control" name="kd_matakuliah" placeholder="Kode Mata Kuliah" style="border-color: var(--bs-purple);" />
		</div>
        <div class="mb-3">
			<input type="text" class="form-control" name="name" placeholder="Nama Mata Kuliah" style="border-color: var(--bs-purple);" />
		</div>
        <div class="mb-3">
			<input type="number" class="form-control" style="border-color: var(--bs-purple);" max="6" min="1" name="sks" placeholder="SKS" />
		</div>
        <div class="mb-3"></div>
        <div class="d-flex justify-content-evenly align-items-center align-items-xxl-center mb-3">
			<button class="btn button button__first" type="submit" name="submit">Submit</button>
		</div>
    </form>
</section>
</div>