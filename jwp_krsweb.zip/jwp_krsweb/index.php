<?php
include('metatag.php');
?>

<body id="page-top">
    <div id="wrapper">
        <?php
        include('navbar.php');
        ?>
        <div class="d-flex flex-column" id="content-wrapper">
            <div id="content">
                <nav class="navbar navbar-light navbar-expand bg-white shadow mb-4 topbar static-top">
                    <div class="container-fluid d-flex justify-content-end">
                        <button class="btn btn-link d-md-none rounded-circle mr-3" id="x " type="button"><i class="fas fa-bars"></i></button>
                        <button class="btn button button__first"><a href="logout.php">Logout</a></button>
                    </div>
                </nav>
                <div class="col justify-content-center">
                    <?php

                    $queries = array();
                    parse_str($_SERVER['QUERY_STRING'], $queries);
                    error_reporting(E_ALL ^ (E_NOTICE | E_WARNING));
                    switch ($queries['page']) {


                        case 'data_mahasiswa':
                            # code...
                            include 'modul/mahasiswa/tampil.php';
                            break;
                        case 'tambah_mahasiswa':
                            # code...
                            include 'modul/mahasiswa/tambah.php';
                            break;
                        case 'edit_mahasiswa':
                            # code...
                            include 'modul/mahasiswa/edit.php';
                            break;
                        case 'delete_mahasiswa':
                            # code...
                            include 'modul/mahasiswa/delete.php';
                            break;

                        case 'data_matakuliah':
                            # code...
                            include 'modul/matakuliah/tampil.php';
                            break;
                        case 'tambah_matakuliah':
                            # code...
                            include 'modul/matakuliah/tambah.php';
                            break;
                        case 'edit_matakuliah':
                            # code...
                            include 'modul/matakuliah/edit.php';
                            break;
                        case 'delete_matakuliah':
                            # code...
                            include 'modul/matakuliah/delete.php';
                            break;

                        case 'data_krs':
                            # code...
                            include 'modul/krs/tampil.php';
                            break;
                        case 'tambah_krs':
                            # code...
                            include 'modul/krs/tambah.php';
                            break;
                        case 'edit_krs':
                            # code...
                            include 'modul/krs/edit.php';
                            break;
                        case 'delete_krs':
                            # code...
                            include 'modul/krs/delete.php';
                            break;

                        default:
                            #code...
                            include 'home.php';
                            break;
                    }
                    ?>

                </div>
                <?php
                include('footer.php');
                ?>