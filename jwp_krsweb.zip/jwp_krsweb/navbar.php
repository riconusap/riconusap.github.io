<nav class="navbar navbar-dark align-items-start sidebar sidebar-dark accordion p-0" style="transition:.2s;background-color: rgba(72, 111, 133, 1);">
    <div class="container-fluid d-flex flex-column p-0 mt-4">
        <a class="navbar-brand d-flex flex-column justify-content-center align-items-center sidebar-brand m-0" href="#" style="margin: 10px;margin-left: 10px;">
            <div class="sidebar-brand-icon mt-4"><img class="rounded-circle" src="./assets/img/profile.jpg" style="width:80px"></div>
        </a>
        <hr class="sidebar-divider my-0 mt-4">
        <ul class="nav navbar-nav text-light" id="accordionSidebar">
            <li class="nav-item" role="presentation"></li>
            <li class="nav-item" role="presentation"><a class="nav-link" href="index.php"><i class="fas fa-home"></i><span>Beranda</span></a></li>
            <?php
            echo $nav__list;
            ?>
        </ul>
        <div class="text-center d-none d-md-inline"><button class="btn rounded-circle border-0" id="sidebarToggle" type="button"></button></div>
    </div>
</nav>