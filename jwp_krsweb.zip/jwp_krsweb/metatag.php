<?php
//session dimulai
session_start();
//abaikan error pada browser
// error_reporting(0);
//panggil file koneksi untuk mengkoneksinkan dengan database
include "./assets/relasi/koneksi.php";
//panggil file security untuk mengecek session admin
include "./assets/relasi/security.php";

$title="";
if (isset($_SESSION['admin'])) {
    $title = "Admin";
    $nav__list = '
    <li class="nav-item" role="presentation"><a class="nav-link" href="index.php?page=data_mahasiswa"><i class="fas fa-table"></i><span>Data Mahasiswa</span></a></li>
    <li class="nav-item" role="presentation"><a class="nav-link" href="index.php?page=data_matakuliah"><i class="fas fa-table"></i><span>Data Mata Kuliah</span></a></li>
    ';
  } else {
    $title = "Mahasiswa";
    $nav__list = '
    <li class="nav-item" role="presentation"><a class="nav-link" href="index.php?page=data_krs"><i class="fas fa-table"></i><span>Isi KRS</span></a></li>
    ';
  }

?>




<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-to-fit=no">
    <title>Dashboard - <?php echo $title ?></title>
    <link rel="stylesheet" href="<?php echo $hostname; ?>assets/bootstrap/css/bootstrap.min.css?h=533bf8cde801c1db51ec98ecb8864293">

    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.12.0/css/all.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    
    <link rel="stylesheet" href="<?php echo $hostname; ?>assets/css/dist/style.css">
    <link rel="stylesheet" href="<?php echo $hostname; ?>assets/css/form.css">

    <script src="https://cdn.ckeditor.com/4.16.0/basic/ckeditor.js"></script>
    <link rel="icon" href="./assets/img/<?php echo $data_setting['logo'] ?>" type="image/png" sizes="26x26">
    
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>  
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.0/jquery.min.js"></script>  
</head>