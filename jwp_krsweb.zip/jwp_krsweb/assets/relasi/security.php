<?php

//jika session tidak sesuai dengan data_admin  maka akan diarahkan ke halaman logout.php atau keluar dari sistem
if (isset($_SESSION['admin']) || isset($_SESSION['mahasiswa'])) {

        if (isset($_SESSION['admin'])) {
                $akun = $_SESSION['admin'];
                $admin = mysqli_fetch_array(mysqli_query($konek, "SELECT * FROM user where id_user='$akun'"));
        } else {
                $akun = $_SESSION['mahasiswa'];
                $admin = mysqli_fetch_array(mysqli_query($konek, "SELECT * FROM user where id_user='$akun' AND level='mahasiswa'"));
        }
} else {
        //jika session sesuai maka session akan digunakan untuk memanggil data dari user
        header('location:logout.php');
}


