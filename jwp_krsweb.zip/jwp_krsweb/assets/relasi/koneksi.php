<?php
//set time zone location sesuai negara, jadikan Asia Jakarta
date_default_timezone_set('Asia/Jakarta');

//**************************start koneksi ***************************//

//set koneksi ke server sesuai host, user, password dan database
$server = "localhost";
$user = "root";
$pass = "";
$database = "db_krs";

//koneksikan ke server
$konek = mysqli_connect($server, $user, $pass, $database) or die('Error Connection Network');

// **************************end koneksi *********************************//

//*********************pengaturan lainnya*****************************//

//buat parameter untuk mempercepat penulisan url misal

$hostname = "http://localhost/JWP_KRSWEB/";
$abspath = $_SERVER['DOCUMENT_ROOT'];

$path_project = $abspath . 'JWP_KRSWEB/assets/img/project/';
$path_logo    = $abspath . 'JWP_KRSWEB/assets/img/';
$path_pdf    = $abspath . 'JWP_KRSWEB/assets/pdf_proposal/';
$path_ava    = $abspath . 'JWP_KRSWEB/assets/img/avatars/';

