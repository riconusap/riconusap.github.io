<center><br><br><br><br><br><br><br><br>
    <img src="./assets/img/logo.jpg" width="400px" height="500px" /> <br>
    <font Size="6" face="Helvetica">Dashboard <?php echo $title; ?></font> <br>
    <font Size="6">JWP_KRS</font>
</center>